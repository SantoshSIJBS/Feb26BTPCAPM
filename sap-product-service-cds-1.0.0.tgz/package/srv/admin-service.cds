using { sap.capire.products as database } from '../db/schema';

service AdminService {

    entity ProudctsSrv as projection on database.Products;

    entity CategoriesSrv as Projection on database.Categories ;
}